﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Data;

namespace DataBindingObjectDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }
        Employee employee;
        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            employee = new Employee();
            employee.FirstName = "Jane";
            employee.LastName = "Doe";
            employee.IsMale = false;

            ContentPanel.DataContext = employee;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(employee.FirstName + " " + employee.LastName);
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            employee.FirstName = "Tom";
            employee.LastName = "Hanks";
        }
    }
}