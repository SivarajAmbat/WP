﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;

namespace DataBindingObjectDemo
{
    public partial class EmployeeList : PhoneApplicationPage
    {
        public EmployeeList()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(EmployeeList_Loaded);
        }
        ObservableCollection<Employee> employees;
        void EmployeeList_Loaded(object sender, RoutedEventArgs e)
        {
            employees = new ObservableCollection<Employee>();
            employees.Add(new Employee { FirstName = "John", LastName = "Doe", IsMale = true, ImageUri="/Images/David.jpg", MobileNumber = "9912345678" });
            employees.Add(new Employee { FirstName = "Jane", LastName = "Doe", IsMale = false, ImageUri = "/Images/Anniston.jpg", MobileNumber = "998765478" });
            employees.Add(new Employee { FirstName = "Peter", LastName = "Parker", IsMale = true, ImageUri = "/Images/Kunal.jpg", MobileNumber = "994567878" });
            employees.Add(new Employee { FirstName = "Mary", LastName = "Jane", IsMale = false, ImageUri = "/Images/Kaley.jpg", MobileNumber = "9934587878" });
            employees.Add(new Employee { FirstName = "Tom", LastName = "Hanks", IsMale = true, ImageUri = "/Images/Sheldon.jpg", MobileNumber = "9976456678" });

            lbxEmployees.ItemsSource = employees;
          

        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            employees.Add(new Employee { FirstName = "Jet", LastName = "Lee", ImageUri = "/Images/David.jpg", MobileNumber = "9876545678" });
        }
    }
}